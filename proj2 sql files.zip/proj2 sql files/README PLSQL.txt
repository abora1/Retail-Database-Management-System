For running the PL SQL code:

1.Copy all the plsql files in your ssl account.
2.Start all the files in the following sequence:
Start tables.sql
Start sequences.sql
Start question2.sql
Start pur_Saving.sql
Start question4.sql
Start question5.sql
Start question6.1.sql
Start question6.2.sql
Start question6.3.sql
Start question6.4.sql
Start question6.5.sql
Start question7.1.sql
Start question7.2.sql
Start question7.3.sql
Start question8.sql
Start question8.1.sql
3.After completion the PL SQL procedures,functions and triggers can be checked through java GUI.
4.Contents:
question6.1.sql,question6.2.sql,question6.3.sql,question6.4.sql,question6.5.sql,question7.2.sql,question7.3.sql,question8.1.sql All CONTAIN TRIGGERS.
sequences.sql contain all the SEQUENCES.
The rest of the files contain procedures and functions.