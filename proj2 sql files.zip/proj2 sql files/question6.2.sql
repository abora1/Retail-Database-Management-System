/* this trigger is used to insert value in logs table when last_visit_date of customer changes
it uses the customers login as input and also the cid of the customer*/

 create or replace trigger on_update_customers
     after update of last_visit_date on customers
     for each row
declare
user login.username%type;
begin
select username into user from login where status='enable';
     insert into logs
values(log_seq.nextval,user,'update',sysdate,'customers',:old.cid);
    end;
    /
