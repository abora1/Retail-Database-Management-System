/* this trigger is used to insert values in logs table when a new supply is ordered*/

 create or replace trigger on_insert_supplies
     after insert on supplies
      for each row
    begin
    insert into logs
values(log_seq.nextval,'admin','insert',sysdate,'supplies',:new.sup#);
   end;
   /

