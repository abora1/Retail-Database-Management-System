/* this procedure is used to delete a purchase,it takes pur# as input and deletes the purchase*/

 create or replace package del_pur as
    procedure delete_purchase(purchase_id in purchases.pur#%type);
    end;
    /

 create or replace package body del_pur as
    procedure delete_purchase(purchase_id in purchases.pur#%type) is
      begin
     delete from purchases where pur#=purchase_id;
     end;
    end;
    /
