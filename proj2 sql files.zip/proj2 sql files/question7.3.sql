/* when a new supply takes place the qoh of products table for the product is added the supply quantity*/

 create or replace trigger on_ins_supp
     after insert on supplies
     for each row
     begin
    update products set qoh=qoh+:new.quantity where pid=:new.pid;
   end;
   /

