/* this trigger is used to insert values in logs table when quantity on hand of products table is updated */

create or replace trigger on_up_prod
     after update of qoh on products
      for each row
     declare
    user login.username%type;
    begin
 select username into user from login where status='enable';
    insert into logs
values(log_seq.nextval,user,'update',sysdate,'products',:new.pid);
   end;
   /
