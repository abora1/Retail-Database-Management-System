/* this function takes the employee id as input and returns its eid,name,its sales for every month,how many transaction it was involved,total quantity sold and total sale in $*/

create or replace package monthly_sales as
    type ref_cursor is ref cursor;
    function monthly_sale_activity(employee_id in Employees.eid%type)
    return ref_cursor;
    end;
    /



create or replace package body monthly_sales as
    function monthly_sale_activity(employee_id in Employees.eid%type)
    return ref_cursor is
    r1 ref_cursor;
    begin
    open r1 for  -- ref cursor is initialized
    select employees.eid,name,to_char(ptime,'MON-YYYY')Month,count(qty)Transaction_involved,sum(qty)total_qty,sum(total_price)total_sale
    from employees,purchases
    where employees.eid=employee_id and
   employees.eid=purchases.eid
   group by employees.eid,to_char(ptime,'MON-YYYY'),name,employee_id
   order by eid;
   return r1;    --the ref cursor returns all values
   end;
   end;
   /

