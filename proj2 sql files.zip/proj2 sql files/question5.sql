/*this procedure is used to add a new customer to the table, it takes the cust_id,name,telephone no as input and inserts default value for visits_made=1 and last_visit_date as current time*/

 create or replace package add_cust as
    procedure add_customer(cust_id in customers.cid%type,cust_name in
customers.name%type,cust_telephone in customers.telephone#%type);-- takes 3 inputs and inserts them
    end;
    /

create or replace package body add_cust as
    procedure add_customer(cust_id in customers.cid%type,cust_name
in customers.name%type,cust_telephone in customers.telephone#%type) is
    begin
    insert into customers
values(cust_id,cust_name,cust_telephone,1,sysdate); --1 and sysdate are default values for visits_made and last_visit date
    end;
    end;
   /
