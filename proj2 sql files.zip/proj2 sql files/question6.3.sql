/* this trigger adds values to logs table when a new purchase is added*/

 create or replace trigger on_insert_purchases
     after insert on purchases
      for each row
     declare
    user login.username%type;  -- for fetching username from login
    begin
 select username into user from login where status='enable';
    insert into logs
values(log_seq.nextval,user,'insert',sysdate,'purchases',:new.pur#);
   end;
   /
