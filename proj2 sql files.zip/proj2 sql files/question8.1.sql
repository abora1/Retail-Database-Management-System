/* when a purchase is deleted the qoh of product is updated and added by quantity deleted
also the last_visit_Date and the visits_made of customer is also updated*/

create or replace trigger on_del_pur
     after delete on purchases
      for each row
     begin
     update products set qoh=qoh+:old.qty where products.pid=:old.pid; -- customer table is updated
     update customers set
visits_made=visits_made+1,last_visit_date=sysdate 
    where customers.cid=:old.cid;
    end;
    /







