/* this package and procedure are used to get details of all tables in database.There are 8 functions defined with cursors for each of them*/

create or replace package get_details as
     type ref_cursor is ref cursor;  -- defining a variable of type cursor
    function getemployees
   return ref_cursor;		-- the cursor returns values through here
    type ref_cursor1 is ref cursor;
    function getproducts
    return ref_cursor1;
   type ref_cursor2 is ref cursor;
   function getpurchases
   return ref_cursor2;
   type ref_cursor3 is ref cursor;
   function getcustomers
   return ref_cursor3;
   type ref_cursor4 is ref cursor;
   function getsuppliers
   return ref_cursor4;
   type ref_cursor5 is ref cursor;
   function getlogs
   return ref_cursor5;
   type ref_cursor6 is ref cursor;
   function getsupplies
   return ref_cursor6;
   type ref_cursor7 is ref cursor;
   function getdiscounts
   return ref_cursor7;
   end;
   /

create or replace package body get_details as
function getemployees
return ref_cursor is
rc ref_cursor;
begin
open rc for             -- cursor starts implementation
select * from employees order by eid;
return rc;         -- cursor returns each row
end;
function getproducts
return ref_cursor1 is
rc1 ref_cursor1;
begin
open rc1 for
select * from products order by pid;
return rc1;
end;
function getpurchases 
return ref_cursor2 is
rc2 ref_cursor2;
begin
open rc2 for
select * from purchases order by pur#;
return rc2;
end;
function getcustomers
return ref_cursor3 is
rc3 ref_cursor3;
begin
open rc3 for
select * from customers order by cid;
return rc3;
end;
function getsuppliers
return ref_cursor4 is
rc4 ref_cursor4;
begin
open rc4 for
select * from suppliers order by sid;
return rc4;
end;
function getlogs
return ref_cursor5 is
rc5 ref_cursor5;
begin
open rc5 for
select * from logs order by log#;
return rc5;
end;
function getsupplies
return ref_cursor6 is
rc6 ref_cursor6;
begin
open rc6 for
select * from supplies order by sup#;
return rc6;
end;
function getdiscounts
return ref_cursor7 is
rc7 ref_cursor7;
begin
open rc7 for
select * from discounts;
return rc7;
end;
end;
/
