/* this procedure is used to add a new purchase to purchases table it takes emp_id,prod_id,cust_id,qty as input and adds it to purchase table
if the purchase quantity is less than qoh then it rejects purchase else it subtracts the qoh by the quantity of purchase */


create or replace package add_pur as
    procedure add_purchase(emp_id in purchases.eid%type,prod_id in
purchases.pid%type,cust_id in purchases.cid%type,pur_qty in
purchases.qty%type);
    end;
    /

create or replace package body add_pur as
    procedure add_purchase(emp_id in purchases.eid%type,prod_id in
purchases.pid%type,cust_id in purchases.cid%type,pur_qty in
purchases.qty%type) is
qoh_prod products.qoh%type;
orig_pr products.original_price%type;
dis_cat products.discnt_category%type;
dis_rate discounts.discnt_rate%type;
    begin
    select qoh into qoh_prod from products
    where products.pid=prod_id;
   if(qoh_prod<pur_qty) then
dbms_output.put_line('Insufficient stock');-- if the quantity purchased is less than available
else
select original_price into orig_pr from products
where pid=prod_id;
select discnt_category into dis_cat from products
where pid=prod_id;
select discnt_rate into dis_rate from discounts
    where discnt_category=dis_cat;
    insert into purchases
values(pur_seq.nextval,emp_id,prod_id,cust_id,pur_qty,sysdate,(orig_pr-(orig_pr*dis_rate))*pur_qty); -- it calculates total_price through the original price and discount rate
end if;
end;
end;
   /
