 /* this trigger is used to update the customer info and product values after an insert in purchase table*/
 /* after insert it updates the qoh by subtracting the purchase quantity and if the qoh falls below threshlod it orderrs new supplies*/
 /* it also updated the last_visit date and the visits made for the customer*/
 
 create or replace trigger on_ins_pur
    after insert on purchases
    for each row
     begin
declare
qoh_val products.qoh%type;
qoh_th products.qoh_threshold%type;
sid_h supplies.sid%type;
begin
    update products set qoh=qoh-:new.qty where products.pid=:new.pid;
select qoh into qoh_val from products where pid=:new.pid;
select qoh_threshold into qoh_th from products where pid=:new.pid;
  if(qoh_val<qoh_th) then -- if the qoh<threshold
    dbms_output.put_line('quantity available is below threshold');
    select min(sid) into sid_h from supplies where pid=:new.pid;-- selecting a supplier from supplies
    insert into supplies
values(sup_seq.nextval,:new.pid,sid_h,sysdate,qoh_th+11); --adding a new supply 
 update customers set
visits_made=visits_made+1,last_visit_date=sysdate  -- customer table is updated
    where customers.cid=:new.cid;
else
 update customers set
visits_made=visits_made+1,last_visit_date=sysdate
    where customers.cid=:new.cid;
   end if;
   end;
end;
   /
