 /* this function is used to calculate total savings for a purchase, it takes the pur# as input and computes the total savings from original price and quantity*/
 
 create or replace package pur_saving as
     function purchase_saving(purchase_no in Purchases.pur#%type) -- function declaration
    return Purchases.total_price%type;   --return type declaration
    end;
    /

create or replace package body pur_saving as
    function purchase_saving(purchase_no in Purchases.pur#%type)
    return Purchases.total_price%type is
    total_savings purchases.total_price%type; --return variable definition
    begin
    select (original_price*qty-((total_price))) into total_savings
    from purchases,products
    where purchase_no=pur# and
    purchases.pid=products.pid;
   return total_savings;  --return variable
   end;
    end;
   /
