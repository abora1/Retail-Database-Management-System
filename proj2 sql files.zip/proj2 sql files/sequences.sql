/* sequences for logs,purchases and supplies tables*/

 create sequence pur_seq increment by 1 start with 100015 maxvalue
999999;

 create sequence sup_seq increment by 1 start with 1010  maxvalue 9999;

create sequence log_seq increment by 1 start with 10001 maxvalue 99999;
